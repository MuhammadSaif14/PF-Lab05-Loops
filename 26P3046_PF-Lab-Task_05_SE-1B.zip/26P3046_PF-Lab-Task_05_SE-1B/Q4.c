#include<stdio.h>
int main(){

	int NOS, MOS, student, passed = 0, failed = 0, total=0, max = 0;

	printf("Enter Number of Students: ");
	scanf("%d", &NOS);
	
	for(student = 1 ; student<=NOS ; student++){
		printf("Marks of Student %d: ", student);
		scanf("%d", &MOS);

		total = total + MOS;

		if(MOS>=50)
			passed++;
		else
			failed++;

		if(MOS > max)
			max = MOS;

		if(student == NOS)
			break;
	}
	
	float avg = (float)total / student;

	printf("Passed: %d\n", passed);
	printf("Failed: %d\n", failed);
	printf("Maximum Number: %d\n", max);
	printf("Average: %.2f", avg);

					

	return 0;
}