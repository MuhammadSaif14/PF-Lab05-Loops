#include<stdio.h>
int main(){

	int choice, quantity, bill=0, items=0, discount=0, payable;

	printf("\n--- MENU ---\n");
	printf("1. Tea \t\t Rs 60\n");
	printf("2. Samosa \t\t Rs 40\n");
	printf("3. Sandwich \t\t Rs 180\n");
	printf("4. Checkout \n\n");

	do{
		printf("Enter Choice: ");
		scanf
		 ("%d", &choice);
	
		if(choice >=1 && choice<=3){
			printf("Quantity: ");
			scanf("%d", &quantity);
			
			if(choice==1)
				bill = bill + 60 * quantity;
			else if(choice == 2)
				bill = bill + 40 * quantity;
			else 
				bill = bill + 180 * quantity;

			items = items + quantity;
			printf("Current bill: Rs %d\n\n", bill);
		}else if(choice != 4)
			printf("Invalid choice. Try again. \n\n");
		
	}while(choice != 4);
		
	if(bill > 1000)
		discount = bill / 10;
	
	payable = bill - discount;	
	
	printf("\n Total Items: %d\n", items);
	printf("Bill: Rs %d\n", bill);
	printf("Discount: Rs %d\n", discount);
	printf("Payable: Rs %d\n", payable);


	return 0;
}
