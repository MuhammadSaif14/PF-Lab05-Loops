#include<stdio.h>
int main(){

	int ball, runs, total=0, B=0, DB=0;

	for(ball=1; ball<=6; ball++){
		printf("Ball %d runs: ", ball);
		scanf("%d", &runs);

		total = total + runs;

		if(runs == 4 || runs == 6)
			B++;
		if(runs==0)
			DB++;
	}

	printf("Total runs: %d \n", total);
	printf("Boundaries: %d \n", B);
	printf("Dot Balls: %d \n", DB);


	return 0;
}