#include <stdio.h>
int main(){

	int pin, attempt = 1, a_left = 3;
	
		do{
			
			printf("Enter ATM Pin: ");
			scanf("%d", &pin);

			if(pin == 4321){
				printf("Access Granted!");
			}
			else{
				a_left = a_left - attempt;

				if(a_left == 2)
					printf("Wrong Pin. %d Attempt left \n", a_left);
				else if(a_left == 1)	
					printf("Wrong Pin. %d Attempt left \n", a_left);

				attempt ++;
				a_left++;
			}

		}while(pin != 4321 && attempt <= 3 && attempt > 0);

		if(pin != 4321)
			printf("Card Blocked. Please contact you bank.");
		


	return 0;
}