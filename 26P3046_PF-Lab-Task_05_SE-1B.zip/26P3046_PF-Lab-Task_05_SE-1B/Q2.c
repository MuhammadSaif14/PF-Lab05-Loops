#include <stdio.h>
int main() {

	int month=0 ,LP,CS ,MS, total;

	printf("Laptop price: ");
	scanf("%d",&LP);                                                                                                                     
	printf("Current savings: ");
	scanf("%d",&CS);
	printf("Monthly savings: ");
	scanf("%d",&MS);

	if(CS>0){
		while(CS<LP){
			CS = CS + MS;
			printf("Month %d: Savings = %d\n", month, CS);
			month++;
		}
		printf("Sara can buy the Laptop after %d month(s).", month);
	}else{
		printf("Sara can buy the Laptop After %d month(s).", month);
	}


	return 0;
}